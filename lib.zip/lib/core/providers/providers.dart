
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/single_child_widget.dart';


List<SingleChildWidget> providers = [

  // BlocProvider<CategoryBloc>(create: (context) => serviceLocator<CategoryBloc>()),
];