class PdfPreviewItem {
  final String path;
  final String? subtitle;
  final String? title;

  PdfPreviewItem({required this.path, this.subtitle, this.title});
}