class DummyCategoryModel{
  final String title, assetPath;

  DummyCategoryModel({required this.title, required this.assetPath});
}